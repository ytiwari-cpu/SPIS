import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ICONS, STATUS_COLORS } from './constants';
import { 
  Programme, 
  ProgrammeStatus, 
  ProgrammeRule, 
  Beneficiary, 
  AuditLog, 
  Activity 
} from './types';

// --- Mock Data ---

const MOCK_PROGRAMMES: Programme[] = [
  {
    id: 'P001',
    master: {
      programme_id: 'P001',
      programme_code: 'NSPS-CASH-01',
      programme_name: 'National Senior Citizens Grant',
      description: 'Direct cash transfer to citizens aged 65 and above living below the poverty line.',
      active_flag: true,
      created_by: 'U001',
      updated_by: 'U001',
      created_at: '2024-01-01T00:00:00Z',
      updated_at: '2024-01-01T00:00:00Z'
    },
    config: {
      programme_id: 'P001',
      ranking_required: true,
      quota_limit: 150000,
      benefit_type: 'Cash',
      benefit_frequency: 'Monthly',
      effective_from: '2024-01-01',
      effective_to: '2025-12-31'
    },
    payment: {
      programme_id: 'P001',
      payment_frequency: 'Monthly',
      payment_mode: 'Direct Deposit',
      total_budget_allocated: 50000000,
      currency: 'USD',
      effective_from: '2024-01-01',
      effective_to: '2025-12-31'
    },
    enrolledCount: 124500,
    eligibleCount: 15000,
    version: 'v2.4'
  },
  {
    id: 'P002',
    master: {
      programme_id: 'P002',
      programme_code: 'NSPS-FOOD-02',
      programme_name: 'Maternal Nutrition Support',
      description: 'In-kind food distribution for pregnant and lactating mothers in rural districts.',
      active_flag: true,
      created_by: 'U001',
      updated_by: 'U001',
      created_at: '2023-06-01T00:00:00Z',
      updated_at: '2023-06-01T00:00:00Z'
    },
    config: {
      programme_id: 'P002',
      ranking_required: false,
      quota_limit: 50000,
      benefit_type: 'In-Kind',
      benefit_frequency: 'Quarterly',
      effective_from: '2023-06-01',
      effective_to: '2024-05-31'
    },
    payment: {
      programme_id: 'P002',
      payment_frequency: 'Quarterly',
      payment_mode: 'In-Kind Distribution',
      total_budget_allocated: 12000000,
      currency: 'USD',
      effective_from: '2023-06-01',
      effective_to: '2024-05-31'
    },
    enrolledCount: 45000,
    eligibleCount: 2000,
    version: 'v1.1'
  }
];

const MOCK_RULES: ProgrammeRule[] = [
  { programme_rule_id: 'R1', programme_id: 'P001', rule_code: 'AGE_MIN', operator: '>=', threshold_value: '65', weight: 10, mandatory_flag: true },
  { programme_rule_id: 'R2', programme_id: 'P001', rule_code: 'INC_MAX', operator: '<=', threshold_value: '200', weight: 40, mandatory_flag: true },
];

const MOCK_BENEFICIARIES: Beneficiary[] = Array.from({ length: 10 }).map((_, i) => ({
  subject_id: `SUBJ-${1000 + i}`,
  programme_id: 'P001',
  subject_type: 'Individual',
  active_from: '2024-03-01',
  active_till: '2024-12-31',
  status: 'Active',
  rule_version: 'v2.4',
  approved_at: '2024-02-15T10:00:00Z',
  calculated_score: 85 + i,
  eligible_flag: true
}));

const MOCK_AUDIT_LOGS: AuditLog[] = [
  { history_id: 'L1', change_type: 'Rule Modified', programme_id: 'P001', changed_by: 'admin_jdoe', changed_at: '2024-02-21T08:45:00Z', old_value: {}, new_value: {} },
];

const MOCK_ACTIVITIES: Activity[] = [
  { id: 'A1', type: 'update', message: 'Programme "National Senior Citizens Grant" updated by admin_jdoe', timestamp: '10 mins ago' },
  { id: 'A2', type: 'rule', message: 'Eligibility rules modified for "Maternal Nutrition Support"', timestamp: '2 hours ago' },
];

// --- Components ---

const Badge = ({ status, active }: { status: string, active?: boolean }) => {
  let colorClass = 'bg-slate-100 text-slate-700 border-slate-200';
  if (active === true || status === 'Active') colorClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
  if (active === false || status === 'Inactive') colorClass = 'bg-slate-100 text-slate-400 border-slate-200';
  if (status === 'Draft') colorClass = 'bg-primary/10 text-primary border-primary/20';
  if (status === 'Ending Soon') colorClass = 'bg-amber-50 text-amber-700 border-amber-200';
  
  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wide ${colorClass}`}>
      {status}
    </span>
  );
};

const MetricCard = ({ title, value, icon: Icon, trend }: { title: string, value: string | number, icon: any, trend?: { val: string, up: boolean } }) => {
  const IconComponent = Icon || ICONS.AlertCircle;
  const UpIcon = ICONS.TrendingUp || ICONS.Plus;
  const DownIcon = ICONS.TrendingDown || ICONS.Plus;

  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">{title}</p>
      <div className="flex items-end justify-between">
        <div className="flex flex-col">
          <p className="text-2xl font-bold text-slate-900">{value}</p>
          {trend && (
            <div className={`flex items-center text-[10px] font-bold mt-1 ${trend.up ? 'text-emerald-600' : 'text-rose-600'}`}>
              {trend.up ? <UpIcon size={12} /> : <DownIcon size={12} />}
              <span className="ml-1">{trend.val}</span>
            </div>
          )}
        </div>
        <IconComponent size={24} className="text-primary/40" />
      </div>
    </div>
  );
};

const SectionHeader = ({ title, subtitle, actions }: { title: string, subtitle?: string, actions?: React.ReactNode }) => (
  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-8">
    <div>
      <h2 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h2>
      {subtitle && <p className="text-sm text-slate-500 mt-1">{subtitle}</p>}
    </div>
    <div className="flex gap-2 w-full sm:w-auto">
      {actions}
    </div>
  </div>
);

const ProgrammeForm = ({ programme, onCancel, onSave }: { programme?: Programme, onCancel: () => void, onSave: (p: any) => void }) => {
  const isEdit = !!programme;
  return (
    <div className="space-y-6">
      <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-lg font-bold flex items-center gap-2 text-slate-900">
            <ICONS.FileText size={20} className="text-primary" />
            Programme Basic Information
          </h2>
          {isEdit && <Badge status="Active" active={true} />}
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1 md:col-span-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Programme Name</label>
            <input 
              type="text" 
              defaultValue={programme?.master.programme_name} 
              className="w-full bg-slate-50 border-slate-200 rounded-lg focus:ring-primary focus:border-primary text-sm font-medium p-2.5" 
              placeholder="e.g. National Senior Citizens Grant" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Code</label>
            <input 
              type="text" 
              defaultValue={programme?.master.programme_code} 
              className="w-full bg-slate-50 border-slate-200 rounded-lg focus:ring-primary focus:border-primary text-sm font-mono p-2.5" 
              placeholder="e.g. SSP-01" 
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Effective Date Range</label>
            <div className="flex items-center gap-2">
              <input 
                type="date" 
                defaultValue={programme?.config.effective_from} 
                className="w-full bg-slate-50 border-slate-200 rounded-lg text-sm p-2.5" 
              />
              <span className="text-slate-400">to</span>
              <input 
                type="date" 
                defaultValue={programme?.config.effective_to} 
                className="w-full bg-slate-50 border-slate-200 rounded-lg text-sm p-2.5" 
              />
            </div>
          </div>
          <div className="space-y-1 md:col-span-2">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Description</label>
            <textarea 
              rows={3} 
              defaultValue={programme?.master.description} 
              className="w-full bg-slate-50 border-slate-200 rounded-lg focus:ring-primary focus:border-primary text-sm p-2.5" 
              placeholder="Describe the programme's objectives..." 
            />
          </div>
        </div>
      </section>

      <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100">
          <h2 className="text-lg font-bold flex items-center gap-2 text-slate-900">
            <ICONS.Settings size={20} className="text-primary" />
            Configuration
          </h2>
        </div>
        <div className="p-6 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
              <div className="space-y-0.5">
                <p className="text-sm font-bold text-slate-900">Ranking Required</p>
                <p className="text-[10px] text-slate-500">Enable algorithmic prioritization</p>
              </div>
              <input 
                type="checkbox" 
                defaultChecked={programme?.config.ranking_required} 
                className="w-10 h-5 rounded-full bg-slate-200 appearance-none checked:bg-primary relative transition-all cursor-pointer before:content-[''] before:absolute before:w-4 before:h-4 before:bg-white before:rounded-full before:top-0.5 before:left-0.5 checked:before:left-5 before:transition-all" 
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Quota Limit</label>
              <input 
                type="number" 
                defaultValue={programme?.config.quota_limit} 
                className="w-full bg-slate-50 border-slate-200 rounded-lg focus:ring-primary focus:border-primary text-sm p-2.5" 
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Benefit Type</label>
              <select className="w-full bg-slate-50 border-slate-200 rounded-lg text-sm p-2.5">
                {['Cash', 'In-Kind', 'Hybrid', 'Service'].map(t => (
                  <option key={t} value={t} selected={programme?.config.benefit_type === t}>{t}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-100">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Frequency</label>
              <select className="w-full bg-slate-50 border-slate-200 rounded-lg text-sm p-2.5">
                {['Monthly', 'Quarterly', 'Annual'].map(f => (
                  <option key={f} value={f} selected={programme?.config.benefit_frequency === f}>{f}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Budget</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold">$</span>
                <input 
                  type="text" 
                  defaultValue={programme?.payment.total_budget_allocated.toLocaleString()} 
                  className="w-full pl-7 bg-slate-50 border-slate-200 rounded-lg focus:ring-primary focus:border-primary text-sm p-2.5" 
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Currency</label>
              <select className="w-full bg-slate-50 border-slate-200 rounded-lg text-sm p-2.5">
                <option>USD - United States Dollar</option>
                <option>EUR - Euro</option>
                <option>GBP - British Pound</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      <div className="flex justify-end gap-3 pb-20">
        <button 
          onClick={onCancel} 
          className="px-6 py-2.5 rounded-lg border border-slate-300 text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors"
        >
          Cancel
        </button>
        <button 
          onClick={() => onSave({})} 
          className="px-10 py-2.5 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all"
        >
          {isEdit ? 'Save Changes' : 'Create Programme'}
        </button>
      </div>
    </div>
  );
};

// --- Main App Component ---

export default function App() {
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [activeSubTab, setActiveSubTab] = useState('Program Details');
  const [selectedProgrammeId, setSelectedProgrammeId] = useState(MOCK_PROGRAMMES[0].id);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [formMode, setFormMode] = useState<'add' | 'edit'>('add');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const selectedProgramme = useMemo(() => 
    MOCK_PROGRAMMES.find(p => p.id === selectedProgrammeId) || MOCK_PROGRAMMES[0]
  , [selectedProgrammeId]);

  const handleEdit = () => {
    setFormMode('edit');
    setIsFormOpen(true);
    setIsSidebarOpen(false);
  };

  const handleAddNew = () => {
    setFormMode('add');
    setIsFormOpen(true);
    setIsSidebarOpen(false);
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setIsSidebarOpen(false);
    setIsFormOpen(false);
  };

  const renderContent = () => {
    if (isFormOpen) {
      return (
        <ProgrammeForm 
          programme={formMode === 'edit' ? selectedProgramme : undefined} 
          onCancel={() => setIsFormOpen(false)} 
          onSave={() => setIsFormOpen(false)} 
        />
      );
    }

    switch (activeTab) {
      case 'Dashboard':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <MetricCard title="Total Active" value="42" icon={ICONS.Programmes} />
              <MetricCard title="Enrolled" value="1.28M" icon={ICONS.Beneficiaries} />
              <MetricCard title="Eligible" value="1.54M" icon={ICONS.Search} />
              <MetricCard title="Cash Dist." value="$450M" icon={ICONS.Payments} />
              <MetricCard title="In-Kind Dist." value="824K" icon={ICONS.Layers} />
              <MetricCard title="Budget Alloc." value="$1.2B" icon={ICONS.Dashboard} />
              <MetricCard title="Remaining" value="$750M" icon={ICONS.Clock} />
              <MetricCard title="Ending Soon" value="03" icon={ICONS.AlertCircle} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <h3 className="font-bold text-slate-900">Programme Overview</h3>
                  <button className="text-xs font-semibold text-[#1d4ed8] hover:text-blue-700 flex items-center">
                    View All <ICONS.ChevronRight size={14} />
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200">
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">ID / Name</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-center">Status</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Budget Utilization</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {MOCK_PROGRAMMES.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col">
                              <span className="text-sm font-bold text-primary">{p.master.programme_code}</span>
                              <span className="text-xs text-slate-500">{p.master.programme_name} ({p.version})</span>
                              <span className="text-[10px] text-slate-400 mt-0.5">Benefit: {p.config.benefit_type}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-center">
                            <Badge status={p.master.active_flag ? 'Active' : 'Inactive'} active={p.master.active_flag} />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="w-32 ml-auto">
                              <div className="flex justify-between items-center mb-1">
                                <span className="text-[10px] font-medium text-slate-500">75%</span>
                                <span className="text-[10px] font-medium text-slate-500">${(p.payment.total_budget_allocated / 1000000).toFixed(1)}M</span>
                              </div>
                              <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full bg-primary rounded-full" style={{ width: '75%' }}></div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <button 
                              onClick={() => {
                                setSelectedProgrammeId(p.id);
                                setActiveTab('Programmes');
                                setActiveSubTab('Program Details');
                              }}
                              className="text-slate-400 hover:text-primary p-1 transition-colors"
                            >
                              <ICONS.FileText size={20} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-bold text-slate-900">System Activity Log</h3>
                  <ICONS.History className="text-slate-400" size={20} />
                </div>
                <div className="space-y-6 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-100">
                  {MOCK_ACTIVITIES.map((activity) => (
                    <div key={activity.id} className="relative pl-8">
                      <div className="absolute left-0 top-1.5 h-6 w-6 rounded-full bg-primary/10 border-4 border-white flex items-center justify-center">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                      </div>
                      <div className="flex flex-col">
                        <p className="text-sm font-medium text-slate-900">{activity.message}</p>
                        <p className="text-xs text-slate-500">{activity.timestamp}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <button 
                  onClick={() => setActiveTab('Audit Logs')}
                  className="w-full mt-6 py-2 text-xs font-bold text-slate-500 hover:text-primary border border-slate-100 rounded-lg transition-colors"
                >
                  View Full Audit Log
                </button>
              </div>
            </div>
          </div>
        );

      case 'Programmes':
        return (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-4 w-full sm:w-auto">
                <label className="text-[10px] sm:text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap">Select Programme:</label>
                <select 
                  className="w-full sm:w-auto bg-slate-50 border border-slate-200 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block p-2 font-semibold text-slate-900"
                  value={selectedProgrammeId}
                  onChange={(e) => setSelectedProgrammeId(e.target.value)}
                >
                  {MOCK_PROGRAMMES.map(p => (
                    <option key={p.id} value={p.id}>{p.master.programme_name}</option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2 w-full sm:w-auto">
                <button 
                  onClick={handleAddNew}
                  className="w-full sm:w-auto px-4 py-2 bg-[#1d4ed8] text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-blue-700 shadow-sm transition-all"
                >
                  <ICONS.Plus size={16} /> Add New
                </button>
              </div>
            </div>

            <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar">
              {['Program Details', 'Rules'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveSubTab(tab)}
                  className={`px-6 py-3 text-sm font-bold transition-all border-b-2 ${
                    activeSubTab === tab 
                      ? 'border-[#1d4ed8] text-[#1d4ed8] bg-[#eff6ff]' 
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {activeSubTab === 'Program Details' ? (
              <div className="space-y-6">
                <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <h2 className="text-lg font-bold flex items-center gap-2 text-slate-900">
                      <ICONS.FileText size={20} className="text-primary" />
                      Programme Basic Information
                    </h2>
                    <Badge status={selectedProgramme.master.active_flag ? 'Active' : 'Inactive'} active={selectedProgramme.master.active_flag} />
                  </div>
                  <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Programme Name</label>
                      <p className="text-sm font-bold text-slate-900">{selectedProgramme.master.programme_name}</p>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Code</label>
                      <p className="text-sm font-mono font-bold text-primary">{selectedProgramme.master.programme_code}</p>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Effective Date Range</label>
                      <p className="text-sm font-medium text-slate-700">{selectedProgramme.config.effective_from} to {selectedProgramme.config.effective_to}</p>
                    </div>
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Description</label>
                      <p className="text-sm text-slate-600 leading-relaxed">{selectedProgramme.master.description}</p>
                    </div>
                  </div>
                </section>

                <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="px-6 py-4 border-b border-slate-100">
                    <h2 className="text-lg font-bold flex items-center gap-2 text-slate-900">
                      <ICONS.Settings size={20} className="text-primary" />
                      Configuration
                    </h2>
                  </div>
                  <div className="p-6 space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                        <div className="space-y-0.5">
                          <p className="text-sm font-bold text-slate-900">Ranking Required</p>
                          <p className="text-[10px] text-slate-500">Enable algorithmic prioritization</p>
                        </div>
                        <div className={`w-10 h-5 rounded-full relative transition-all ${selectedProgramme.config.ranking_required ? 'bg-primary' : 'bg-slate-200'}`}>
                          <div className={`absolute w-4 h-4 bg-white rounded-full top-0.5 transition-all ${selectedProgramme.config.ranking_required ? 'left-5' : 'left-0.5'}`}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Quota Limit</label>
                        <p className="text-sm font-bold text-slate-900">{selectedProgramme.config.quota_limit.toLocaleString()} Members</p>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Benefit Type</label>
                        <span className="inline-block px-2 py-0.5 bg-primary/10 text-primary rounded text-[10px] font-bold uppercase tracking-wider">{selectedProgramme.config.benefit_type}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-100">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Frequency</label>
                        <p className="text-sm font-bold text-slate-900">{selectedProgramme.config.benefit_frequency}</p>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Budget</label>
                        <p className="text-sm font-bold text-slate-900">{selectedProgramme.payment.currency} {selectedProgramme.payment.total_budget_allocated.toLocaleString()}</p>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Currency</label>
                        <p className="text-sm font-bold text-slate-900">{selectedProgramme.payment.currency}</p>
                      </div>
                    </div>
                  </div>
                </section>

                <div className="flex justify-end gap-3 pb-20">
                  <button 
                    onClick={handleEdit}
                    className="px-6 py-2.5 rounded-lg border border-primary text-primary text-sm font-bold hover:bg-primary/5 transition-colors"
                  >
                    Edit Programme
                  </button>
                  <button 
                    className="px-10 py-2.5 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all"
                  >
                    Create New Version
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-base font-bold flex items-center gap-2 text-slate-900">
                      <ICONS.Layers size={18} className="text-primary" />
                      Visual Rule Builder
                    </h2>
                    <span className="text-[10px] font-bold px-2 py-1 bg-amber-100 text-amber-700 rounded uppercase tracking-wider">Draft Mode</span>
                  </div>

                  <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <ICONS.GripVertical className="text-slate-400 cursor-grab" size={18} />
                        <div className="flex bg-white border border-slate-200 rounded-lg p-1">
                          <button className="px-3 py-1 text-[10px] font-bold bg-primary text-white rounded">AND</button>
                          <button className="px-3 py-1 text-[10px] font-bold text-slate-500 hover:bg-slate-50 rounded">OR</button>
                        </div>
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Global Requirement Group</span>
                      </div>
                      <button className="text-slate-400 hover:text-rose-500 transition-colors">
                        <ICONS.Trash2 size={16} />
                      </button>
                    </div>
                    <div className="p-4 space-y-4">
                      <div className="flex flex-col md:flex-row gap-3 items-start md:items-center p-3 rounded-lg border border-slate-100 bg-white">
                        <ICONS.GripHorizontal className="text-slate-300 hidden md:block cursor-grab" size={18} />
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 w-full">
                          <div className="col-span-2 md:col-span-1">
                            <label className="text-[10px] uppercase font-bold text-slate-400 mb-1 block">Field</label>
                            <select className="w-full text-xs border-slate-200 rounded bg-slate-50 p-1.5 font-medium">
                              <option>Applicant Age</option>
                              <option>Monthly Income</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400 mb-1 block">Operator</label>
                            <select className="w-full text-xs border-slate-200 rounded bg-slate-50 p-1.5 font-medium">
                              <option>Greater than</option>
                              <option>Equal to</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400 mb-1 block">Value</label>
                            <input className="w-full text-xs border-slate-200 rounded bg-slate-50 p-1.5 font-medium" type="number" defaultValue="18"/>
                          </div>
                          <div>
                            <label className="text-[10px] uppercase font-bold text-slate-400 mb-1 block">Weight</label>
                            <input className="w-full text-xs border-slate-200 rounded bg-slate-50 p-1.5 font-medium" type="number" defaultValue="0"/>
                          </div>
                          <div className="flex items-center justify-between md:justify-end gap-4 pt-4 md:pt-0">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] uppercase font-bold text-slate-400">Mandatory</span>
                              <div className="w-8 h-4 bg-primary rounded-full relative transition-colors cursor-pointer">
                                <div className="absolute right-0.5 top-0.5 w-3 h-3 bg-white rounded-full shadow-sm"></div>
                              </div>
                            </div>
                            <button className="text-slate-400 hover:text-rose-500 md:ml-2">
                              <ICONS.Plus size={18} className="rotate-45" />
                            </button>
                          </div>
                        </div>
                      </div>

                      <button className="flex items-center gap-2 text-primary text-[10px] font-bold px-4 py-2 rounded-lg border border-dashed border-primary/40 hover:bg-primary/5 transition-colors uppercase tracking-wider">
                        <ICONS.Plus size={14} /> Add Condition
                      </button>
                    </div>
                  </div>
                </section>

                <section>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-base font-bold flex items-center gap-2 text-slate-900">
                      <ICONS.History size={18} className="text-primary" />
                      Active Rule Inventory
                    </h2>
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span> {MOCK_RULES.length} Total Rules
                    </div>
                  </div>
                  <div className="space-y-3">
                    {MOCK_RULES.map((rule) => (
                      <div key={rule.programme_rule_id} className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm hover:border-primary/30 transition-all">
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-slate-400 tracking-widest uppercase">CODE: {rule.rule_code}</span>
                            <h3 className="font-bold text-sm text-slate-900">{rule.rule_code} Requirement</h3>
                          </div>
                          <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-wider">Demographic</span>
                        </div>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs border-t border-slate-50 pt-3">
                          <div>
                            <p className="text-slate-400 font-bold uppercase text-[9px] mb-1">Operator</p>
                            <p className="font-bold text-slate-700">{rule.operator} {rule.threshold_value}</p>
                          </div>
                          <div>
                            <p className="text-slate-400 font-bold uppercase text-[9px] mb-1">Weight</p>
                            <p className="font-bold text-slate-700">{rule.weight}% Points</p>
                          </div>
                          <div>
                            <p className="text-slate-400 font-bold uppercase text-[9px] mb-1">Status</p>
                            <p className="font-bold text-emerald-600 uppercase">Active</p>
                          </div>
                          <div className="flex justify-end gap-2">
                            <button className="p-1.5 rounded bg-slate-50 text-slate-400 hover:text-primary transition-colors">
                              <ICONS.FileText size={14} />
                            </button>
                            <button className="p-1.5 rounded bg-slate-50 text-slate-400 hover:text-rose-500 transition-colors">
                              <ICONS.Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            )}
          </div>
        );

      case 'Beneficiaries':
        return (
          <div className="space-y-6">
            <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar">
              {['Enrolled', 'Eligible'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveSubTab(tab)}
                  className={`px-6 py-3 text-sm font-bold transition-all border-b-2 whitespace-nowrap ${
                    activeSubTab === tab 
                      ? 'border-primary text-primary bg-primary/5' 
                      : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
                <div className="relative w-full sm:w-80">
                  <ICONS.Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="Search by UUID (subject_id)..." 
                    className="w-full bg-white border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none"
                  />
                </div>
                <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-50 flex items-center justify-center gap-2">
                  <ICONS.Filter size={16} /> Filters
                </button>
              </div>
              <div className="flex gap-2 w-full md:w-auto">
                <button className="flex-1 md:flex-none px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-50 flex items-center justify-center gap-2">
                  <ICONS.Download size={16} /> Export CSV
                </button>
                {activeSubTab === 'Eligible' && (
                  <button className="flex-1 md:flex-none px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 flex items-center justify-center gap-2 shadow-sm">
                    <ICONS.RefreshCw size={16} /> Recalculate
                  </button>
                )}
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      {activeSubTab === 'Enrolled' ? (
                        <>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">UUID (subject_id)</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Prog ID</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rule Ver</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Approved At</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Active From</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-center">Status</th>
                        </>
                      ) : (
                        <>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">UUID (subject_id)</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Score</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rule Ver</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Evaluated At</th>
                          <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Actions</th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {MOCK_BENEFICIARIES.map((b, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs font-bold text-primary">{b.subject_id}</td>
                        {activeSubTab === 'Enrolled' ? (
                          <>
                            <td className="px-6 py-4 text-xs text-slate-600 font-medium">{b.programme_id}</td>
                            <td className="px-6 py-4 text-xs text-slate-500">{b.rule_version}</td>
                            <td className="px-6 py-4 text-xs text-slate-500">{new Date(b.approved_at).toLocaleDateString()}</td>
                            <td className="px-6 py-4 text-xs text-slate-500">{b.active_from}</td>
                            <td className="px-6 py-4 text-center">
                              <Badge status="Active" />
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="px-6 py-4 font-bold text-primary text-sm">{b.calculated_score}</td>
                            <td className="px-6 py-4 text-xs text-slate-500">{b.rule_version}</td>
                            <td className="px-6 py-4">
                              <span className="text-emerald-600 flex items-center gap-1 text-[10px] font-bold uppercase tracking-wide"><ICONS.CheckCircle2 size={14} /> Eligible</span>
                            </td>
                            <td className="px-6 py-4 text-xs text-slate-500">{new Date(b.approved_at).toLocaleDateString()}</td>
                            <td className="px-6 py-4 text-right">
                              <button className="text-xs font-bold text-primary hover:underline">View Evaluation</button>
                            </td>
                          </>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'Payments':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Total Disbursed</span>
                  <ICONS.CreditCard size={20} className="text-primary/40" />
                </div>
                <div className="text-2xl font-bold text-slate-900">$47.2M</div>
                <div className="text-[10px] text-emerald-600 font-bold mt-1 flex items-center gap-1">
                  <ICONS.TrendingUp size={12} /> +12.5% from last cycle
                </div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Pending Batch</span>
                  <ICONS.Clock size={20} className="text-primary/40" />
                </div>
                <div className="text-2xl font-bold text-slate-900">$2.4M</div>
                <div className="text-[10px] text-amber-600 font-bold mt-1">3 batches awaiting approval</div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Failed Txns</span>
                  <ICONS.AlertCircle size={20} className="text-rose-400/40" />
                </div>
                <div className="text-2xl font-bold text-slate-900">1,240</div>
                <div className="text-[10px] text-rose-500 font-bold mt-1">0.8% failure rate</div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Active Cycles</span>
                  <ICONS.History size={20} className="text-primary/40" />
                </div>
                <div className="text-2xl font-bold text-slate-900">12</div>
                <div className="text-[10px] text-slate-500 font-bold mt-1">Next cycle in 4 days</div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="font-bold text-slate-900">Recent Payment Cycles</h3>
                <button className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-bold hover:bg-primary/90 flex items-center gap-2 shadow-sm">
                  <ICONS.Plus size={16} /> New Payment Cycle
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-[10px] tracking-wider border-b border-slate-100">
                    <tr>
                      <th className="px-6 py-3">Cycle ID</th>
                      <th className="px-6 py-3">Programme</th>
                      <th className="px-6 py-3">Period</th>
                      <th className="px-6 py-3">Amount</th>
                      <th className="px-6 py-3">Recipients</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[
                      { id: 'CYC-2024-001', prog: 'National Cash Transfer', period: 'Jan 2024', amount: '$12.5M', recipients: '45,000', status: 'Completed' },
                      { id: 'CYC-2024-002', prog: 'Disability Support', period: 'Jan 2024', amount: '$4.2M', recipients: '12,500', status: 'Processing' },
                      { id: 'CYC-2024-003', prog: 'Elderly Pension', period: 'Jan 2024', amount: '$8.8M', recipients: '32,000', status: 'Pending Approval' },
                    ].map((cycle, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs font-bold text-primary">{cycle.id}</td>
                        <td className="px-6 py-4 font-bold text-slate-900">{cycle.prog}</td>
                        <td className="px-6 py-4 text-slate-600">{cycle.period}</td>
                        <td className="px-6 py-4 font-bold text-slate-900">{cycle.amount}</td>
                        <td className="px-6 py-4 text-slate-600">{cycle.recipients}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            cycle.status === 'Completed' ? 'bg-emerald-100 text-emerald-700' :
                            cycle.status === 'Processing' ? 'bg-blue-100 text-blue-700' :
                            'bg-amber-100 text-amber-700'
                          }`}>
                            {cycle.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="text-slate-400 hover:text-primary transition-colors">
                            <ICONS.FileText size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'Reports':
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Enrollment Report', desc: 'Detailed breakdown of beneficiary enrollment by programme and period.', icon: ICONS.Users },
                { title: 'Budget Utilization', desc: 'Analysis of allocated vs utilized budget across all active programmes.', icon: ICONS.BarChart },
                { title: 'Geo Distribution', desc: 'Beneficiary distribution mapped by administrative geo codes.', icon: ICONS.Layers },
                { title: 'Rule Performance', desc: 'Evaluation of eligibility rule effectiveness and exclusion rates.', icon: ICONS.ShieldCheck },
              ].map((report, i) => (
                <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:border-blue-300 transition-all cursor-pointer group">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 w-fit mb-4 group-hover:bg-blue-50 group-hover:border-blue-100 transition-all">
                    <report.icon size={24} className="text-slate-600 group-hover:text-[#1d4ed8] transition-all" />
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">{report.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mb-6">{report.desc}</p>
                  <button className="text-xs font-bold text-[#1d4ed8] flex items-center gap-1 hover:underline">
                    Generate Report <ICONS.ChevronRight size={14} />
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6 pb-2 border-b border-slate-100">Report Filters</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Programme</label>
                  <select className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm">
                    <option>All Programmes</option>
                    {MOCK_PROGRAMMES.map(p => <option key={p.id}>{p.master.programme_name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Date Range</label>
                  <div className="flex gap-2">
                    <input type="date" className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm" />
                    <input type="date" className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Status</label>
                  <select className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-sm">
                    <option>All Statuses</option>
                    <option>Active</option>
                    <option>Pending</option>
                    <option>Terminated</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        );

      case 'Audit Logs':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 className="font-bold text-slate-900">System Audit Logs</h3>
                <button className="px-3 py-1.5 bg-white border border-slate-200 text-slate-700 rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-slate-50">
                  <ICONS.Download size={14} /> Export Logs
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-[10px] tracking-wider border-b border-slate-100">
                    <tr>
                      <th className="px-6 py-3">Action Type</th>
                      <th className="px-6 py-3">Programme ID</th>
                      <th className="px-6 py-3">Changed By</th>
                      <th className="px-6 py-3">Changed At</th>
                      <th className="px-6 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {MOCK_AUDIT_LOGS.map((log) => (
                      <tr key={log.history_id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold uppercase">{log.change_type}</span>
                        </td>
                        <td className="px-6 py-4 font-semibold text-slate-900">{log.programme_id}</td>
                        <td className="px-6 py-4 font-mono text-xs text-slate-600">{log.changed_by}</td>
                        <td className="px-6 py-4 text-slate-500">{new Date(log.changed_at).toLocaleString()}</td>
                        <td className="px-6 py-4">
                          <button className="text-xs font-bold text-[#1d4ed8] hover:underline">View Details</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      default:
        return <div className="p-12 text-center text-slate-400 font-medium">Module coming soon...</div>;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      {/* Mobile Sidebar Backdrop */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/50 z-30 lg:hidden backdrop-blur-sm"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 w-72 bg-white border-r border-slate-200 flex flex-col z-40 transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-auto
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 flex items-center justify-between border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center shadow-sm">
              <ICONS.ShieldCheck className="text-white" size={18} />
            </div>
            <h1 className="text-lg font-bold text-slate-900 tracking-tight">NSPS Admin</h1>
          </div>
          <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-slate-400 hover:text-slate-600">
            <ICONS.Plus size={24} className="rotate-45" />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto no-scrollbar">
          {[
            { name: 'Dashboard', icon: ICONS.Dashboard },
            { name: 'Programmes', icon: ICONS.Programmes },
            { name: 'Beneficiaries', icon: ICONS.Beneficiaries },
            { name: 'Payments', icon: ICONS.Payments },
            { name: 'Reports', icon: ICONS.Reports },
            { name: 'Audit Logs', icon: ICONS.AuditLogs },
            { name: 'Settings', icon: ICONS.Settings },
          ].map((item) => (
            <button
              key={item.name}
              onClick={() => handleTabChange(item.name)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all group ${
                activeTab === item.name 
                  ? 'bg-primary/10 text-primary' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon size={20} className={activeTab === item.name ? 'text-primary' : 'text-slate-400 group-hover:text-slate-600'} />
              {item.name}
            </button>
          ))}
        </nav>

        <div className="p-4 bg-slate-50 border-t border-slate-100">
          <div className="flex items-center gap-3 px-2">
            <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30 overflow-hidden">
              <span className="text-primary font-bold text-xs">JD</span>
            </div>
            <div className="flex flex-col overflow-hidden">
              <p className="text-sm font-bold truncate text-slate-900">John Doe (Lead)</p>
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Dept. of Social Welfare</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 z-10 sticky top-0">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 -ml-2 text-slate-500 hover:text-slate-700 lg:hidden"
            >
              <ICONS.GripVertical size={20} />
            </button>
            <div className="flex flex-col">
              <h1 className="text-base lg:text-lg font-bold leading-tight tracking-tight text-slate-900">NSPS Administration</h1>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Programme Module</p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-4">
            <button className="relative p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors">
              <ICONS.AlertCircle size={20} />
              <span className="absolute top-2 right-2 flex h-2 w-2 rounded-full bg-red-500 ring-2 ring-white"></span>
            </button>
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30">
              <ICONS.User size={16} className="text-primary" />
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="max-w-7xl mx-auto"
          >
            <SectionHeader 
              title={activeTab} 
              subtitle={`Manage and monitor ${activeTab.toLowerCase()} for the National Social Protection System.`}
            />
            {renderContent()}
          </motion.div>
        </div>
      </main>
    </div>
  );
}
