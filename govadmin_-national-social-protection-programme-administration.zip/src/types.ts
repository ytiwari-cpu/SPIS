export type ProgrammeStatus = 'Draft' | 'Active' | 'Inactive' | 'Ending Soon';
export type BenefitType = 'Cash' | 'In-Kind' | 'Hybrid' | 'Service';

export interface ProgrammeMaster {
  programme_id: string;
  programme_code: string;
  programme_name: string;
  description: string;
  active_flag: boolean;
  created_by: string;
  updated_by: string;
  created_at: string;
  updated_at: string;
}

export interface ProgrammeConfig {
  programme_id: string;
  ranking_required: boolean;
  quota_limit: number;
  benefit_type: BenefitType;
  benefit_frequency: string;
  effective_from: string;
  effective_to: string;
}

export interface ProgrammePaymentSettings {
  programme_id: string;
  payment_frequency: string;
  payment_mode: string;
  total_budget_allocated: number;
  currency: string;
  effective_from: string;
  effective_to: string;
}

export interface Programme {
  id: string;
  master: ProgrammeMaster;
  config: ProgrammeConfig;
  payment: ProgrammePaymentSettings;
  enrolledCount: number;
  eligibleCount: number;
  version: string;
}

export interface RuleMaster {
  rule_code: string;
  category: string;
  rule_name: string;
  description: string;
  data_type: string;
  source_entity: string;
  created_at: string;
}

export interface ProgrammeRule {
  programme_rule_id: string;
  programme_id: string;
  rule_code: string;
  operator: string;
  threshold_value: string;
  weight: number;
  mandatory_flag: boolean;
}

export interface RuleVersionMaster {
  rule_version: string;
  description: string;
  effective_from: string;
  effective_to: string;
  created_at: string;
}

export interface Beneficiary {
  programme_id: string;
  subject_type: string;
  subject_id: string;
  active_from: string;
  active_till: string;
  status: string;
  rule_version: string;
  approved_at: string;
  calculated_score?: number;
  eligible_flag?: boolean;
}

export interface AuditLog {
  history_id: string;
  programme_id: string;
  change_type: string;
  old_value: any;
  new_value: any;
  changed_by: string;
  changed_at: string;
}

export interface Activity {
  id: string;
  type: 'update' | 'rule' | 'version' | 'approval';
  message: string;
  timestamp: string;
}
