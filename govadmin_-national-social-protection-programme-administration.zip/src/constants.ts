import { 
  LayoutDashboard, 
  Briefcase, 
  Users, 
  CreditCard, 
  BarChart, 
  History, 
  Settings,
  Plus,
  Search,
  Filter,
  Download,
  MoreVertical,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  FileText,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Layers,
  GitBranch,
  Trash2,
  GripVertical,
  GripHorizontal,
  User,
  RefreshCw
} from 'lucide-react';

export const ICONS = {
  Dashboard: LayoutDashboard,
  Programmes: Briefcase,
  Beneficiaries: Users,
  Payments: CreditCard,
  Reports: BarChart,
  AuditLogs: History,
  Settings: Settings,
  Users,
  CreditCard,
  History,
  BarChart,
  Plus,
  Search,
  Filter,
  Download,
  MoreVertical,
  ChevronRight,
  AlertCircle,
  CheckCircle2,
  Clock,
  FileText,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Layers,
  GitBranch,
  Trash2,
  GripVertical,
  GripHorizontal,
  User,
  RefreshCw
};

export const STATUS_COLORS = {
  Draft: 'bg-slate-100 text-slate-700 border-slate-200',
  Active: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Inactive: 'bg-slate-100 text-slate-400 border-slate-200',
  'Ending Soon': 'bg-amber-50 text-amber-700 border-amber-200',
};

export const BENEFIT_TYPES = ['Cash', 'In-Kind', 'Hybrid'];
export const RULE_CATEGORIES = ['Demographic', 'Economic', 'Health', 'Compliance'];
export const OPERATORS = ['==', '!=', '>', '<', '>=', '<=', 'IN', 'NOT IN'];
